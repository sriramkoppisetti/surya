Note
====

Responsive Mobile First Web Template 
Author URI: http://webthemez.com/
Description: Ace is a responsive coming soon template, It is lightweight template comes with image slideshow background overlay pattern.
License: Free to use for personal and commercial, but you need to place back link in the bottom of the template(Template by: webthemez.com).


Credits
=======
Slider - http://vegas.jaysalvat.com/
Images	Unsplash (http://unsplash.com - CC0 licensed)
	